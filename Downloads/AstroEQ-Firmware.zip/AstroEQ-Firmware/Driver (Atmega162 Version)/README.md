
### Notice for Windows 10 Users

Installation of this driver is not necessary.

Windows 10 comes with a compatible driver preinstalled so it should automatically detect and install the necessary driver.
