Replace the following two files:

HardwareSerial.h
HardwareSerial.cpp

In the directory:

<arduino install>\hardware\arduino\cores\arduino\

--------------------------------------

Replace the following file:

iom162.h

In the directory:

<arduino install>\hardware\tools\avr\avr\include\avr\