Replace the following two files:

HardwareSerial.h
HardwareSerial.cpp

In the directory:

<arduino install>\hardware\arduino\cores\arduino