### For Windows 10 Users

Installation of this driver is not necessary.

Windows 10 comes with a compatible driver preinstalled so it should automatically detect and install the necessary driver.

### For Window Vista/7/8.1 Users

Running DPInst_x86 or DPInst_x64 will install the AstroEQ driver (Use _x86 for 32bit OS, or _x64 for 64bit OS).
Alternatively you can install via Device Manager